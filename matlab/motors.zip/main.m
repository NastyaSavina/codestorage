t = 0.7;
w = 32212;
mu = 3.e-21;
tau = 22222222;
k = 2.e-19;
D = 100;
u = -1;
T = -55;
lambda = 0:0.01:1;
lambda_0 = 0.5;

a = D * power(k, 2);
b = D * power(k, 2);

v_mid_val = v_mid(u, T, D, lambda, lambda_0, k, a, b, mu, t, tau, w);

plot(lambda, v_mid_val(1,:));
axis([0 1 min(v_mid_val) max(v_mid_val)]);