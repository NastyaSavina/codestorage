function res = beta(T)
    res = power(1.38064852 * power(10, -23) * T, -1);
end