function w_res = w_j(j)
    tau=1;
    w_res =  2 * pi * j /tau;
end